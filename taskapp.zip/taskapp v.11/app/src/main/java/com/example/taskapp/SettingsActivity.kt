package com.example.taskapp

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.taskapp.databinding.ActivitySettingsBinding


class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        sharedPreferences = getSharedPreferences("TaskApp", MODE_PRIVATE)

        loadSettings()

        binding.btnSaveSettings.setOnClickListener {
            val newUserName = binding.editUserName.text.toString()

            if (newUserName.isNotBlank()) {
                sharedPreferences.edit().putString("userName", newUserName).apply()  // Use "userName" como a chave
                Toast.makeText(this, "Nome de usuário atualizado! $newUserName", Toast.LENGTH_SHORT).show()

                // Voltar para a MainActivity
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Nome de usuário inválido!", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnBack.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun loadSettings() {
        val userName = sharedPreferences.getString("userName", "Usuário não definido")
        binding.editUserName.setText(userName)
    }
}
